import { Component, OnInit } from '@angular/core';
import {ActivatedRoute,Router,ParamMap} from '@angular/router';
import { MatchService } from '../service/match.service';
@Component({
  selector: 'app-matches-detail-component',
  templateUrl: './matches-detail-component.component.html',
  styleUrls: ['./matches-detail-component.component.css']
})
export class MatchesDetailComponentComponent implements OnInit {
  public comp_id;
  detail_result = [];
  constructor(private route:ActivatedRoute,
              private router:Router,
              private matchService : MatchService,
            ) { }

  ngOnInit() {
    this.route.paramMap.subscribe((params:ParamMap)=>{
      let id = parseInt(params.get("id"));
      this.comp_id = id;
      console.log("comp_id",this.comp_id);
      });

      this.getmatchesDetails();
      this.GetMatchesByCompetitionId();
     
  }
    getmatchesDetails(){
      this.matchService.GetAllCompetitions_ById(this.comp_id).subscribe(data=>{
        //console.log("GetAllCompetitions_ById",data);
        this.detail_result = data['data'];
        console.log("GetCompetitionStandingById",this.detail_result);
     });
     

    }

    GetMatchesByCompetitionId(){
      this.matchService.GetMatchesByCompetition_ById(this.comp_id).subscribe(data=>{
        console.log("GetMatchesByCompetition_ById",data);
     });  
    }





    gotomatch(){
      let selectedId = this.comp_id ?  this.comp_id : null;
      // this.router.navigate(['/Department',{id:selectedId,name:"test"}]);
      this.router.navigate(['../',{id:selectedId}],{relativeTo:this.route})
    }
}
